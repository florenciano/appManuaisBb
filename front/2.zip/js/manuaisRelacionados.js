manuaisBB.controller("manuaisRelacionados", function ($scope) { 

	$scope.blackboardBb = [
	// BLACKBOARD: Conhecendo o ambiente
	{
		'manual'		: 	'Primeiro nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina.html'
	},
	{
		'manual'		: 	'Segundo nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina-2.html'
	},
	{
		'manual'		: 	'Terceiro nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina-3.html'
	},
	{
		'manual'		: 	'Quarto nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina-4.html'
	}
	];

	// BLACKBOARD: Materiais
	$scope.BbMateriais = [
	{
		'manual'		: 	'Primeiro nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina.html'
	}
	]

});