manuaisBB.controller("manuaisRelacionados", function ($scope) { 

	$scope.manuais = [
	// BLACKBOARD: Nome da categoria
	{
		'manual'		: 	'Primeiro nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina.html'
	},
	{
		'manual'		: 	'Segundo nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina-2.html'
	},
	{
		'manual'		: 	'Terceiro nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina-3.html'
	},
	{
		'manual'		: 	'Quarto nome do manual relacioando fica aqui',
		'linkManual'	: 	'/enderecoLink/subDiretorio/nomeDaPagina-4.html'
	}
	];

});