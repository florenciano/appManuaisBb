manuaisBB.controller("manuaisRelacionados", function ($scope) { 

	$scope.manuais = [
	{
		'manual'		: 	'Primeiro nome do manual relacioando fica aqui',
		'linkManual'	: 	'/blackboard/sub1'
	},
	{
		'manual'		: 	'Segundo nome do manual relacioando fica aqui',
		'linkManual'	: 	'/blackboard/sub2'
	}
	];

});